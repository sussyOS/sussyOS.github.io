/* Remove leading underscore from the gcc generated symbol names */
#define STRIP_UNDERSCORE

#include "obj-format.h"

/* end of te-sysv32.h */
